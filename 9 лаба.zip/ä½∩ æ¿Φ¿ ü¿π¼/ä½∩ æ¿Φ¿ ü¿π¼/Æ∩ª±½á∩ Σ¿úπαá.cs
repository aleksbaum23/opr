﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Для_Сиши_Биум
{
    internal class Тяжёлая_фигура : Шахматная_фигура  
    {
        public Тяжёлая_фигура()
        {
            Console.WriteLine("Тяжёлая фигура");
        }
    }
}
