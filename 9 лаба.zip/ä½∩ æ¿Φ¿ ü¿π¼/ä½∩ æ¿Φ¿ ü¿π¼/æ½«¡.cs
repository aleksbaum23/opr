﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Для_Сиши_Биум
{
    internal class Слон : Лёгкая_фигура
    {
        public Слон()
        {
            Console.WriteLine("Ходит по диагонали");
            Console.WriteLine("Стоит 3 пешки");
        }
    }
}
