﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Для_Сиши_Биум
{
    internal class Король : Шахматная_фигура
    {
        public Король()
        {
            Console.WriteLine("Двигается в любую сторону на одну клетку");
            Console.WriteLine("Самая главная фигура в шахматах");
            Console.WriteLine("Если королю ставят мат, то партия заканчивается");
        }

        public string Castling(string king, uint king_, string rookLeft, uint rookLeft_, string rookRight, uint rookRight_)
        {

            if (king_ == 1 && (king == "D" || king == "d") && rookLeft_ == 1 && (rookLeft == "A" || rookLeft == "a") && rookRight_ != 1 || (rookRight != "H" || rookRight != "h"))
            {
                return "Король может рокироваться только в левую сторону";
            }

            else if (king_ == 1 && (king == "D" || king == "d") && rookLeft_ != 1 || (rookLeft != "A" || rookLeft != "a") && rookRight_ == 1 && (rookRight == "H" || rookRight == "h"))
            {
                return "Король может рокироваться только в правую сторону";
            }

            else if (king_ == 1 && (king == "D" || king == "d") && rookLeft_ == 1 && (rookLeft == "A" || rookLeft == "a") && rookRight_ == 1 && (rookRight == "H" || rookRight == "h"))
            {
                return "Король может рокироваться в обе стороны";
            }

            else return "Король не может рокироваться";
        }

    }
}
