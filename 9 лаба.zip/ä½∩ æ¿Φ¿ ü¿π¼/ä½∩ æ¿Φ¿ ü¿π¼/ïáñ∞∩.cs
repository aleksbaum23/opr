﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Для_Сиши_Биум
{
    internal class Ладья : Тяжёлая_фигура
    {
        public Ладья() {

            Console.WriteLine("Ходит по вертикали и горизонтали");
            Console.WriteLine("Стоит 5 пешек");

        }
    }
}
