﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Для_Сиши_Биум
{
    internal class Лёгкая_фигура : Шахматная_фигура
    {
        public Лёгкая_фигура()
        {
            Console.WriteLine("Лёгкая фигура"); 
        }
    }
}
