﻿using System.Net.NetworkInformation;
using System.Runtime.ConstrainedExecution;
using System.Xml.Serialization;

namespace Для_Сиши_Биум
{
    internal class Program
    {
        static void Main(string[] args)
        {

            while (true)
            {

                Console.WriteLine("Введите число на клавиатуре, чтобы выбрать шахмутную фигуру и вывести её свойства или выйти из программы:");
                Console.WriteLine();
                Console.WriteLine("1. Пешка");
                Console.WriteLine("2. Слон");
                Console.WriteLine("3. Ладья");
                Console.WriteLine("4. Король");
                Console.WriteLine("5. Выйти из программы");

                uint choice;

            Found1:
                try
                {
                    choice = uint.Parse(Console.ReadLine());
                    if (!(choice >= 1 && choice <= 5))
                    {
                        Console.WriteLine("Вы ввели число, не входящий в диапазон чисел от 1 до 4. Повторите попытку");
                        goto Found1;
                    }

                    

                }
                catch
                {
                    Console.WriteLine("Вы ввели некорретное значение числа. Повторите попытку");
                    goto Found1;
                }

                if (choice == 5) goto Final;

                switch (choice)
                {

                    case 1:

                        Пешка пешка = new Пешка();
                        Console.WriteLine(пешка);
                        break;

                    case 2:

                        Слон слон = new Слон();
                        Console.WriteLine(слон);
                        break;

                    case 3:

                        Ладья ладья = new Ладья();
                        Console.WriteLine(ладья);
                        break;

                    case 4:

                        Король король = new Король();
                        Console.WriteLine($"{король} \n");

                        Console.WriteLine("Чтобы проверить, может ли король белых рокироваться, введите клетки, на которых стоят король и две ладьи");

                        string king, rookLeft, rookRight;
                        uint king_, rookLeft_, rookRight_;

                    //Клетка короля

                    Found2:

                        Console.WriteLine("Введите букву клетки короля:");
                        king = Console.ReadLine();

                        Console.WriteLine("Введите номер клетки короля:");

                    Number_king:
                        try
                        {
                            king_ = uint.Parse(Console.ReadLine());
                        }
                        catch
                        {
                            Console.WriteLine("Вы ввели некорретное значение номера клетки. Повторите попытку");
                            goto Number_king;
                        }

                        //Клетка левой ладьи

                        Console.WriteLine("Введите букву клетки левой ладьи:");
                        rookLeft = Console.ReadLine();

                        Console.WriteLine("Введите номер клетки левой ладьи:");

                    Number_rookLeft:
                        try
                        {
                            rookLeft_ = uint.Parse(Console.ReadLine());
                        }
                        catch
                        {
                            Console.WriteLine("Вы ввели некорретное значение номера клетки. Повторите попытку");
                            goto Number_rookLeft;
                        }

                        //Клетка правой ладьи

                        Console.WriteLine("Введите букву клетки правой ладьи:");
                        rookRight = Console.ReadLine();

                        Console.WriteLine("Введите номер клетки правой ладьи:");

                    Number_rookRight:
                        try
                        {
                            rookRight_ = uint.Parse(Console.ReadLine());
                        }
                        catch
                        {
                            Console.WriteLine("Вы ввели некорретное значение номера клетки. Повторите попытку");
                            goto Number_rookRight;
                        }

                        if (!(1 <= king_ && king_ <= 8 && (king == "A" || king == "a" || king == "B" || king == "b" || king == "C" || king == "c" || king == "D" || king == "d" || king == "E" || king == "e" || king == "F" || king == "f" || king == "G" || king == "g" || king == "H" || king == "h")))
                        {
                            Console.WriteLine("Вы ввели неверные значения клеток поля. Повторите попытку");
                            goto Found2;
                        }

                        Console.WriteLine(король.Castling(king, king_, rookLeft, rookLeft_, rookRight, rookRight_));
                        break;
                        
                }
            

            }
            Final:;
        }
    }
}
