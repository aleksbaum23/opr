﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Для_Сиши_Биум
{
    internal class Пешка : Лёгкая_фигура
    {

        public Пешка() {

            Console.WriteLine("Ходит на одну клетку вперёд");
            Console.WriteLine("Если достигнет конца поля, то может превратиться в любую из фигур, кроме короля");
        }

    }
}
