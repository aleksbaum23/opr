﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Для_Сиши_Биум
{
    internal abstract class Шахматная_фигура 
    {
        public Шахматная_фигура() {

            Console.WriteLine("Шахматная фигура");

        }
    }
}
